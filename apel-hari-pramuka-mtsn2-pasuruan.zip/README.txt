APEL HARI PRAMUKA MTsN 2 PASURUAN
=================================

Isi project:
- index.html
- assets/foto-utama.jpg
- assets/foto-2.jpg
- assets/foto-3.jpg
- assets/foto-4.jpg

Cara menjalankan:
1. Ekstrak ZIP.
2. Buka index.html di browser.

Upload ke Vercel:
- Upload folder/project ini melalui GitHub, lalu import repository ke Vercel.
- Tidak membutuhkan build command karena website berupa HTML/CSS/JS statis.

Fitur:
- Hero berita modern
- Galeri foto + lightbox
- Mode gelap
- Progress membaca
- Daftar isi
- Tombol ukuran teks
- Tombol cetak
- Tombol bagikan
- Responsive untuk HP dan desktop
